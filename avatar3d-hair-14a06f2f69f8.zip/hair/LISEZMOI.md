# Coiffures du personnage 3D

57 coiffures des paquets de la communauté MakeHuman `hair01` (CC0), `hair02` et `hair03` (CC-BY), ajustées sur la tête du modèle `mpfb` par D.FUSE (positions, UV, normales et indices dans `hXX.json`, texture grise normalisée dans `hXX.webp`, vignette dans `t/`). Le moteur les recolore avec la couleur de cheveux choisie.

**CC-BY** : l'usage commercial et la revente sont permis, à condition de créditer les auteurs. Ce fichier et `credits.json` (copié dans l’APK, les .md ne le sont pas) sont le crédit : ils doivent rester livrés avec D.FUSE. Les coiffures CC0 n'imposent rien ; leurs auteurs sont cités par politesse.

L'ordre de `HAIR_MESHES` dans `js/avatar-core.mjs` est enregistré dans le code du visage : on ajoute à la fin, sans jamais retirer ni déplacer.

| Fichier | Nom dans le studio | Groupe | Licence | Auteur | Auteur d'origine | Source |
|---|---|---|---|---|---|---|
| `h01` | Afro | Courtes | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2817 (`elvs_micky_afro`) |
| `h02` | Brosse | Courtes | CC-BY | culturalibre | ucupumar | http://www.makehumancommunity.org/node/2421 (`culturalibre_hair_13`) |
| `h03` | Carré ondulé | Courtes | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1551 (`elvs_wavy_bob`) |
| `h04` | Carré rentré | Courtes | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1677 (`toigo_curled_under_bob`) |
| `h05` | Carré rentré à frange | Courtes | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1689 (`toigo_curled_under_bob_with_bangs`) |
| `h06` | Coupe au bol | Courtes | CC0 | littleright | — | http://www.makehumancommunity.org/node/936 (`littleright_bobcut_hair`) |
| `h07` | Coupe courte | Courtes | CC0 | culturalibre | — | http://www.makehumancommunity.org/node/2445 (`culturalibre_hair_05`) |
| `h08` | Coupe militaire | Courtes | CC-BY | culturalibre | madsoul666 | http://www.makehumancommunity.org/node/2428 (`culturalibre_hair_14`) |
| `h09` | Courts coiffés | Courtes | CC-BY | culturalibre | miccall | http://www.makehumancommunity.org/node/2482 (`culturalibre_hair_18`) |
| `h10` | Courts en bataille | Courtes | CC0 | Cortu | — | http://www.makehumancommunity.org/node/2809 (`cortu_short_messy_hair`) |
| `h11` | Courts homme | Courtes | CC0 | culturalibre | — | http://www.makehumancommunity.org/node/2892 (`culturalibre_hair_02`) |
| `h12` | Courts plaqués | Courtes | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1639 (`elvs_maxwell_hair`) |
| `h13` | Courts rebelles | Courtes | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2796 (`elvs_grump_hair`) |
| `h14` | Courts simples | Courtes | CC0 | Faydaen | — | http://www.makehumancommunity.org/node/2667 (`faydaen_hair_1`) |
| `h15` | Courts texturés | Courtes | CC0 | culturalibre | — | http://www.makehumancommunity.org/node/2479 (`culturalibre_hair_06`) |
| `h16` | Bandeau | Mi-longues | CC0 | sonntag78 | — | http://www.makehumancommunity.org/node/207 (`sonntag78_blond_with_headband`) |
| `h17` | Carré bouclé | Mi-longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2683 (`elvs_inverted_curly_bob`) |
| `h18` | Carré net | Mi-longues | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1669 (`toigo_blunt_bob`) |
| `h19` | Carré net à frange | Mi-longues | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1681 (`toigo_blunt_bob_with_bangs`) |
| `h20` | Carré plongeant | Mi-longues | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1673 (`toigo_inverted_bob`) |
| `h21` | Carré plongeant à frange | Mi-longues | CC0 | MargaretToigo | — | http://www.makehumancommunity.org/node/1685 (`toigo_inverted_bob_with_bangs`) |
| `h22` | Carré à frange | Mi-longues | CC-BY | punkduck | — | http://www.makehumancommunity.org/node/1474 (`o4saken_chinesebob01`) |
| `h23` | Dégradé hirsute | Mi-longues | CC0 | Cortu | — | http://www.makehumancommunity.org/node/2811 (`cortu_shaggy_green_hair`) |
| `h24` | Frange droite | Mi-longues | CC0 | Cortu | — | http://www.makehumancommunity.org/node/2810 (`cortu_straight_bangs`) |
| `h25` | Longs frisés | Mi-longues | CC-BY | punkduck | — | http://www.makehumancommunity.org/node/480 (`punkduck_alpha7_curly`) |
| `h26` | Mi-courts avec fleurs | Mi-longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1860 (`elvs_short_daisy_hair`) |
| `h27` | Mi-longs ondulés | Mi-longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1863 (`elvs_katherine_hair`) |
| `h28` | Mèches longues | Mi-longues | CC-BY | culturalibre | RodAlln | http://www.makehumancommunity.org/node/2043 (`culturalibre_hair_12`) |
| `h29` | Nuage bouclé | Mi-longues | CC0 | Cortu | — | http://www.makehumancommunity.org/node/2808 (`cortu_strawberry_cloud_hair`) |
| `h30` | Perruque à nœud | Mi-longues | CC-BY | grinsegold | — | http://www.makehumancommunity.org/node/173 (`grinsegold_wig_bow_tie`) |
| `h31` | Petit carré | Mi-longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1710 (`elvs_witchy_lil_bob`) |
| `h32` | Sauvage | Mi-longues | CC0 | sonntag78 | — | http://www.makehumancommunity.org/node/174 (`sonntag78_junglebook_hair`) |
| `h33` | Volume années 80 | Mi-longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1861 (`elvs_ashley_may_hair`) |
| `h34` | Frisés années 80 | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2174 (`elvs_that_80s_babe_hair`) |
| `h35` | Hippie | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1812 (`elvs_lady_hippy_hair`) |
| `h36` | Longs avec fleurs | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1859 (`elvs_daisy_hair`) |
| `h37` | Longs bouclés | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1862 (`elvs_adrienne_hair`) |
| `h38` | Longs des îles | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1811 (`elvs_island_princess_hair`) |
| `h39` | Longs dégradés | Longues | CC-BY | punkduck | — | http://www.makehumancommunity.org/node/492 (`punkduck_alpha7_long2`) |
| `h40` | Longs effilés | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2173 (`elvs_keylth_hair`) |
| `h41` | Longs lisses | Longues | CC0 | punkduck | — | http://www.makehumancommunity.org/node/1471 (`o4saken_long01`) |
| `h42` | Longs ondulés | Longues | CC-BY | culturalibre | miccall | http://www.makehumancommunity.org/node/2481 (`culturalibre_hair_17`) |
| `h43` | Longs raides | Longues | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2816 (`elvs_hazel_hair`) |
| `h44` | Mi-longs frisés | Longues | CC-BY | punkduck | — | http://www.makehumancommunity.org/node/477 (`punkduck_alpha7_curly2`) |
| `h45` | Mi-longs lisses | Longues | CC0 | culturalibre | — | http://www.makehumancommunity.org/node/2893 (`culturalibre_hair_01`) |
| `h46` | Très longs | Longues | CC-BY | punkduck | — | http://www.makehumancommunity.org/node/482 (`punkduck_alpha7_long`) |
| `h47` | Chignon années 50 | Tresses et chignons | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2001 (`elvs_50s_updo`) |
| `h48` | Chignon de sage | Tresses et chignons | CC-BY | culturalibre | Kavzekenza | http://www.makehumancommunity.org/node/2027 (`culturalibre_hair_11`) |
| `h49` | Chignon et tresses | Tresses et chignons | CC-BY | grinsegold | — | http://www.makehumancommunity.org/node/172 (`grinsegold_wig_bun_blonde_braids`) |
| `h50` | Chignon haut | Tresses et chignons | CC0 | RehmanPolanski | — | http://www.makehumancommunity.org/node/2477 (`rehmanpolanski_hair_bun_brown`) |
| `h51` | Chignon tresse inversée | Tresses et chignons | CC0 | Elvaerwyn | — | http://www.makehumancommunity.org/node/1337 (`elvs_reverse_french_braid_bun`) |
| `h52` | Chignon tressé | Tresses et chignons | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2177 (`elvs_braid_bun`) |
| `h53` | Deux tresses | Tresses et chignons | CC0 | Elvaerwyn | — | http://www.makehumancommunity.org/node/1336 (`elvs_double_mh_braid`) |
| `h54` | Natte d’aventurière | Tresses et chignons | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/2634 (`elvs_lara_hair`) |
| `h55` | Tresse africaine | Tresses et chignons | CC0 | Elvaerwyn | — | http://www.makehumancommunity.org/node/1335 (`elvs_french_braid_variation`) |
| `h56` | Tresse décoiffée | Tresses et chignons | CC0 | Elvaerwyn | — | http://www.makehumancommunity.org/node/1334 (`elvs_unkempt_french_braid`) |
| `h57` | Tresses collées | Tresses et chignons | CC-BY | Elvaerwyn | — | http://www.makehumancommunity.org/node/1659 (`elvs_braided_rows`) |
