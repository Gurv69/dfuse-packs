# Peaux du personnage 3D

Les 56 peaux de ce dossier viennent des paquets de peaux de la communauté MakeHuman (`skins01`, `skins02`, `skins03`, makehumancommunity.org), publiés en **CC0 1.0** (domaine public) : usage commercial et revente permis, sans obligation.

Elles ont été réduites en JPEG 2048 × 2048 pour D.FUSE. `t/` contient les vignettes du studio, rendues avec le moteur de D.FUSE. L'ordre de `SKIN_TEXTURES` dans `js/avatar-core.mjs` est enregistré dans le code du visage : on ajoute les nouvelles peaux à la fin, sans jamais en retirer ni en déplacer.

| Fichier | Nom dans le studio | Groupe | Paquet | Peau d'origine (auteur_nom) |
|---|---|---|---|---|
| `k01.jpg` | Uniforme claire | Femmes | skins01 | blindsaypatten_uniform_skin_texture |
| `k02.jpg` | Jeune femme | Femmes | skins01 | bobby_03_young_female_hairless |
| `k03.jpg` | Teint mat | Femmes | skins01 | callharvey3d_midtoned_female |
| `k04.jpg` | Indienne contrastée | Femmes | skins01 | cutoff3d_indian_female_enhanced |
| `k05.jpg` | Indienne | Femmes | skins01 | cutoff3d_indian_female_skin |
| `k06.jpg` | Européenne | Femmes | skins01 | darthfurby_caucasian_female |
| `k07.jpg` | Rousse | Femmes | skins01 | flower-angel_red_head_skin |
| `k08.jpg` | Zoey | Femmes | skins01 | nyloseth_zoeyskin |
| `k09.jpg` | Eurasienne, 45 ans | Femmes | skins01 | onlytheghosts_middle_aged_eurasian_female |
| `k10.jpg` | Eurasienne âgée | Femmes | skins01 | onlytheghosts_old_eurasian_female |
| `k11.jpg` | Eurasienne jeune | Femmes | skins01 | onlytheghosts_young_eurasian_female |
| `k12.jpg` | Européenne naturelle | Femmes | skins01 | saltycowdawg_genuine_caucasian_female_with_genitals |
| `k13.jpg` | Peau crème | Femmes | skins01 | skalldyrssuppe_creamy_female |
| `k14.jpg` | Alana | Femmes | skins01 | spreadcore_alana_caucasian_female_with_genitals_skin |
| `k15.jpg` | Bronzée | Femmes | skins01 | toigo_light_skin_female_bronze |
| `k16.jpg` | Bronzée maquillée | Femmes | skins01 | toigo_light_skin_female_bronze_with_makeup |
| `k17.jpg` | Taches de rousseur | Femmes | skins01 | toigo_light_skin_female_freckles |
| `k18.jpg` | Rousse claire | Femmes | skins01 | toigo_light_skin_female_ginger |
| `k19.jpg` | Rousse claire 2 | Femmes | skins01 | toigo_light_skin_female_ginger_2 |
| `k20.jpg` | Rousse maquillée | Femmes | skins01 | toigo_light_skin_female_ginger_with_makeup |
| `k21.jpg` | Maquillage violet | Femmes | skins01 | toigo_light_skin_female_with_violet_makeup |
| `k22.jpg` | Claire maquillée | Femmes | skins01 | toigo_light_skin_with_makeup |
| `k23.jpg` | Maquillage naturel | Femmes | skins01 | toigo_light_skin_with_natural_makeup |
| `k24.jpg` | Slave barbu | Hommes | skins02 | jartur69_middleage_slavic_male_with_genitals_and_beard |
| `k25.jpg` | Slave âgé barbu | Hommes | skins02 | jartur69_old_slavic_male_with_genitals_and_beard |
| `k26.jpg` | Tatoué | Hommes | skins02 | ken1138_caucasian_male_tattooed_skin |
| `k27.jpg` | Aksel | Hommes | skins02 | mindfront_aksel_skin |
| `k28.jpg` | Africain | Hommes | skins02 | mindfront_skin_male_african_middleage |
| `k29.jpg` | Eurasien âgé | Hommes | skins02 | onlytheghosts_old_eurasian_male |
| `k30.jpg` | Viking tatoué | Hommes | skins02 | rehmanpolanski_skin_viking_tattoos |
| `k31.jpg` | Bronzé | Hommes | skins02 | toigo_light_skin_male_bronze |
| `k32.jpg` | Taches de rousseur | Hommes | skins02 | toigo_light_skin_male_freckles |
| `k33.jpg` | Roux | Hommes | skins02 | toigo_light_skin_male_ginger |
| `k34.jpg` | Emo | Hommes | skins02 | toigo_light_skin_male_with_emo_eyes |
| `k35.jpg` | Eye-liner | Hommes | skins02 | toigo_light_skin_male_with_eyeliner |
| `k36.jpg` | Gothique | Hommes | skins02 | toigo_light_skin_male_with_goth_makeup |
| `k37.jpg` | Peau grise | Fantaisie | skins03 | bobby_03_grey_skinned_person |
| `k38.jpg` | Elfe | Fantaisie | skins03 | bogdan666_elfskinsohlen |
| `k39.jpg` | Babouin | Fantaisie | skins03 | callharvey3d_baboon_people |
| `k40.jpg` | Bleu lumineux | Fantaisie | skins03 | culturalibre_dr_manhattan |
| `k41.jpg` | Tigresse | Fantaisie | skins03 | culturalibre_tigra_skin |
| `k42.jpg` | Tigresse blanche | Fantaisie | skins03 | culturalibre_tigra_white_skin |
| `k43.jpg` | Anatomie annotée | Fantaisie | skins03 | joepal_annotated_skin |
| `k44.jpg` | Zombie | Fantaisie | skins03 | naim_abbassi_zombie_skin |
| `k45.jpg` | Léopard bleu | Fantaisie | skins03 | reizibarrientos_blue_leopard_skin |
| `k46.jpg` | Spectre glacé | Fantaisie | skins03 | reizibarrientos_white_walker_skin |
| `k47.jpg` | Zombie 2 | Fantaisie | skins03 | sohh_female_zombie_skin |
| `k48.jpg` | Orc | Fantaisie | skins03 | sonntag78_orkifyheadtarget_custom_skin |
| `k49.jpg` | Alien gris armuré | Fantaisie | skins03 | spreadcore_gray_alien_bio_armor_skin_1 |
| `k50.jpg` | Alien vert | Fantaisie | skins03 | spreadcore_green_alien_skin_1 |
| `k51.jpg` | Alien vert 2 | Fantaisie | skins03 | spreadcore_green_alien_skin_2 |
| `k52.jpg` | Drapeau trans | Fantaisie | skins03 | titleknown_trans_flag |
| `k53.jpg` | Fourrure noire | Fantaisie | skins03 | trashhunter_black_kameri_fur |
| `k54.jpg` | Combinaison verte | Fantaisie | skins03 | xhado84_middleage_afro_female_special_suit_green |
| `k55.jpg` | Combinaison or | Fantaisie | skins03 | xhado84_young_asian_female_body_suit_gold |
| `k56.jpg` | Combinaison rouge | Fantaisie | skins03 | xhado84_young_asian_female_special_suit_red |
