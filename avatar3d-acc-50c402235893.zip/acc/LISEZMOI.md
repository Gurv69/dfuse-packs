# Accessoires 3D (sourcils, barbes, cornes, chapeaux, casques, masques, tenues)

Modèles de la communauté MakeHuman (makehumancommunity.org), ajustés sur la tête mpfb par le convertisseur D.FUSE.
Licences : CC0 (domaine public) ou **CC-BY 4.0** : pour ces derniers, citer l’auteur quand D.FUSE est diffusé.

Les textures des sourcils, barbes et cornes sont en gris pour suivre la couleur choisie dans le studio. Les tenues (a79–a93) gardent leurs couleurs et remplacent la tenue de base sur le buste ; elles sont coupées sous la poitrine et gonflées de 2 mm. Ordre fixe (code du visage) : ne pas renuméroter.

| id | Nom | Licence | Auteur | Source |
|---|---|---|---|---|
| a01 | Barbes : Barbe hirsute | CC0 | WDG | http://www.makehumancommunity.org/node/1769 |
| a02 | Barbes : Barbe de Sigmund | CC0 | grinsegold | http://www.makehumancommunity.org/node/877 |
| a03 | Barbes : Barbe viking | CC0 | RehmanPolanski | http://www.makehumancommunity.org/node/2614 |
| a04 | Barbes : Moustache viking | CC0 | RehmanPolanski | http://www.makehumancommunity.org/node/2615 |
| a05 | Barbes : Barbe de faune | CC0 | culturalibre | http://www.makehumancommunity.org/node/2356 |
| a06 | Cornes : Bois de cerf | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2376 |
| a07 | Cornes : Bois d’élan | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2375 |
| a08 | Cornes : Corne de licorne | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2385 |
| a09 | Cornes : Cornes de démon | CC-BY | JALdMIC | http://www.makehumancommunity.org/node/2947 |
| a10 | Cornes : Cornes de dragonne | CC0 | FreezyChan | http://www.makehumancommunity.org/node/1564 |
| a11 | Cornes : Cornes de faune | CC0 | culturalibre | http://www.makehumancommunity.org/node/2355 |
| a12 | Cornes : Cornes de gazelle | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2388 |
| a13 | Cornes : Cornes de minotaure | CC0 | culturalibre | http://www.makehumancommunity.org/node/2352 |
| a14 | Cornes : Cornes de molosse | CC0 | JALdMIC | http://www.makehumancommunity.org/node/2995 |
| a15 | Cornes : Cornes de taureau | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2379 |
| a16 | Cornes : Petites cornes | CC-BY | JALdMIC | http://www.makehumancommunity.org/node/2935 |
| a17 | Chapeaux : Casquette plate | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1814 |
| a18 | Chapeaux : Casquette gavroche | CC0 | jujube | http://www.makehumancommunity.org/node/78 |
| a19 | Chapeaux : Casquette militaire | CC-BY | Mindfront | http://www.makehumancommunity.org/node/841 |
| a20 | Chapeaux : Bonnet ample | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2088 |
| a21 | Chapeaux : Bonnet de bain | CC-BY | punkduck | http://www.makehumancommunity.org/node/663 |
| a22 | Chapeaux : Bonnet de Noël | CC0 | Joel Palmius | http://www.makehumancommunity.org/node/520 |
| a23 | Chapeaux : Bonnet de père Noël | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1273 |
| a24 | Chapeaux : Bonnet tricoté | CC-BY | Mindfront | http://www.makehumancommunity.org/node/745 |
| a25 | Chapeaux : Bob | CC-BY | Mindfront | http://www.makehumancommunity.org/node/337 |
| a26 | Chapeaux : Chapeau melon | CC-BY | culturalibre | http://www.makehumancommunity.org/node/3089 |
| a27 | Chapeaux : Chapeau cloche | CC0 | Aethelraed_Unraed | http://www.makehumancommunity.org/node/582 |
| a28 | Chapeaux : Chapeau de Don Quichotte | CC-BY | culturalibre | http://www.makehumancommunity.org/node/3037 |
| a29 | Chapeaux : Chapeau de magicien | CC-BY | MaciekG | http://www.makehumancommunity.org/node/1481 |
| a30 | Chapeaux : Chapeau de sorcière | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1708 |
| a31 | Chapeaux : Chapka | CC-BY | Mindfront | http://www.makehumancommunity.org/node/3172 |
| a32 | Chapeaux : Coiffe à plumes | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1312 |
| a33 | Chapeaux : Coiffe de dentelle | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1575 |
| a34 | Chapeaux : Haut-de-forme | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1360 |
| a35 | Chapeaux : Toque de chef | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2967 |
| a36 | Chapeaux : Trilby | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/1413 |
| a37 | Chapeaux : Visière | CC-BY | punkduck | http://www.makehumancommunity.org/node/694 |
| a38 | Chapeaux : Voile | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2610 |
| a39 | Casques : Bombe d’équitation | CC-BY | punkduck | http://www.makehumancommunity.org/node/1567 |
| a40 | Casques : Casque à cornes | CC-BY | MaciekG | http://www.makehumancommunity.org/node/1487 |
| a41 | Casques : Casque d’aviateur | CC-BY | MaciekG | http://www.makehumancommunity.org/node/1457 |
| a42 | Casques : Casque colonial | CC-BY | DredNicolson | http://www.makehumancommunity.org/node/415 |
| a43 | Casques : Casque corinthien | CC0 | grinsegold | http://www.makehumancommunity.org/node/667 |
| a44 | Casques : Casque crâne | CC0 | culturalibre | http://www.makehumancommunity.org/node/2349 |
| a45 | Casques : Casque de vélo | CC-BY | punkduck | http://www.makehumancommunity.org/node/670 |
| a46 | Casques : Casque dragon | CC0 | culturalibre | http://www.makehumancommunity.org/node/2351 |
| a47 | Casques : Casque de guerrier | CC-BY | culturalibre | http://www.makehumancommunity.org/node/2505 |
| a48 | Casques : Casque de moto | CC0 | culturalibre | http://www.makehumancommunity.org/node/2025 |
| a49 | Casques : Casque militaire | CC-BY | JALdMIC | http://www.makehumancommunity.org/node/2942 |
| a50 | Casques : Casque KZ45 | CC-BY | Mindfront | http://www.makehumancommunity.org/node/1310 |
| a51 | Casques : Heaume de templier | CC0 | javherre | http://www.makehumancommunity.org/node/2014 |
| a52 | Masques : Masque chirurgical | CC0 | Joel Palmius | http://www.makehumancommunity.org/node/2369 |
| a53 | Masques : Masque en tissu | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2523 |
| a54 | Masques : Bandana | CC-BY | culturalibre | http://www.makehumancommunity.org/node/2483 |
| a55 | Masques : Masque à gaz | CC-BY | Mathias_Gredal | http://www.makehumancommunity.org/node/2715 |
| a56 | Masques : Masque de médecin de peste | CC-BY | Elvaerwyn | http://www.makehumancommunity.org/node/2371 |
| a57 | Masques : Masque de héros 1 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2055 |
| a58 | Masques : Masque de héros 2 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2049 |
| a59 | Masques : Masque de héros 3 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2202 |
| a60 | Masques : Masque de héros 4 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2220 |
| a61 | Masques : Masque de héros 5 | CC-BY | culturalibre | http://www.makehumancommunity.org/node/2396 |
| a62 | Masques : Masque d’héroïne | CC0 | culturalibre | http://www.makehumancommunity.org/node/2474 |
| a63 | Masques : Cagoule 1 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2100 |
| a64 | Masques : Cagoule 2 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2309 |
| a65 | Sourcils : Fins | CC0 | Mindfront | http://www.makehumancommunity.org/node/1964 |
| a66 | Sourcils : Fins arqués | CC0 | Mindfront | http://www.makehumancommunity.org/node/1965 |
| a67 | Sourcils : Droits | CC0 | Mindfront | http://www.makehumancommunity.org/node/1966 |
| a68 | Sourcils : Doux | CC0 | Mindfront | http://www.makehumancommunity.org/node/1967 |
| a69 | Sourcils : Longs épais | CC0 | Mindfront | http://www.makehumancommunity.org/node/1968 |
| a70 | Sourcils : Naturels | CC0 | Mindfront | http://www.makehumancommunity.org/node/1969 |
| a71 | Sourcils : Épais | CC0 | Mindfront | http://www.makehumancommunity.org/node/1970 |
| a73 | Sourcils : Dessinés | CC0 | Mindfront | http://www.makehumancommunity.org/node/1972 |
| a74 | Sourcils : Arqués | CC0 | Mindfront | http://www.makehumancommunity.org/node/1973 |
| a75 | Sourcils : Arqués fins | CC0 | Mindfront | http://www.makehumancommunity.org/node/1974 |
| a76 | Sourcils : Courts | CC0 | Mindfront | http://www.makehumancommunity.org/node/1975 |
| a77 | Sourcils : Broussailleux | CC0 | Mindfront | http://www.makehumancommunity.org/node/1976 |
| a78 | Sourcils : Touffus | CC0 | Mindfront | http://www.makehumancommunity.org/node/1977 |
| a79 | Tenues : Super-héros 1 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2061 |
| a80 | Tenues : Super-héros 2 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2292 |
| a81 | Tenues : Super-héros 3 | CC0 | culturalibre | http://www.makehumancommunity.org/node/2308 |
| a82 | Tenues : Super-héroïne | CC0 | culturalibre | http://www.makehumancommunity.org/node/2317 |
| a83 | Tenues : Combinaison | CC0 | MatCreator | http://www.makehumancommunity.org/node/2879 |
| a84 | Tenues : Combinaison moulante | CC0 | MatCreator | http://www.makehumancommunity.org/node/2991 |
| a85 | Tenues : Armure Hélios | CC0 | MatCreator | http://www.makehumancommunity.org/node/2881 |
| a86 | Tenues : Armure Jupiter | CC0 | MatCreator | http://www.makehumancommunity.org/node/2882 |
| a87 | Tenues : Robot | CC0 | joachip | http://www.makehumancommunity.org/node/3204 |
| a88 | Tenues : Uniforme galactique | CC0 | TheGreatEngineer | http://www.makehumancommunity.org/node/2884 |
| a89 | Tenues : Combinaison spatiale | CC0 | green_tomato | http://www.makehumancommunity.org/node/3228 |
| a90 | Tenues : Combinaison pilote | CC0 | green_tomato | http://www.makehumancommunity.org/node/3239 |
| a91 | Tenues : Araignée | CC0 | Slayer227 | http://www.makehumancommunity.org/node/2977 |
| a92 | Tenues : Tunique viking | CC0 | RehmanPolanski | http://www.makehumancommunity.org/node/2617 |
| a93 | Tenues : Robe de moine | CC0 | Donitz | http://www.makehumancommunity.org/node/3238 |
| a94 | Chapeaux : Capuche de moine | CC0 | Donitz | http://www.makehumancommunity.org/node/3235 |
